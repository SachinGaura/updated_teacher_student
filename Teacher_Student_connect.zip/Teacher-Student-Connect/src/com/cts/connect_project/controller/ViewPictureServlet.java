package com.cts.connect_project.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.connect_project.bean.Image;
import com.cts.connect_project.util.DBUtils;

/**
 * Servlet implementation class ViewPictureServlet
 */
@WebServlet("/ViewPictureServlet")
public class ViewPictureServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewPictureServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    private Image getImageInTable(Connection conn, String id) throws SQLException {
   	 String sql = "Select * from user where userid=?";
        PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setString(1, id);
        Image p = null;
        ResultSet rs = pstm.executeQuery();
        if (rs.next()) {
            String name = rs.getString("userid");
            System.out.println(rs.getString("fname"));
            byte[] imageData = rs.getBytes("pic");
            String imageFileName = rs.getString("userid");
            return new Image(id, name, imageFileName, imageData);}
        else
        {return null;}
        }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection conn = null;
	      try {
	          // Get Database Connection.
	         // (See more in JDBC Tutorial)
	          conn = DBUtils.getConnection();
	          System.out.println(request.getParameter("id"));
      	String id = null;  //request.getParameter("id");

	          try {
	              id = request.getParameter("id") ;
         
	          } catch (Exception e) {
	 
	          }
	          Image person = getImageInTable(conn, id);
	          
	          if (person == null) {
	              // No record found, redirect to default image.
	              response.sendRedirect(request.getContextPath() + "/images/noimage.jpg");
	              return;
	          }
	        
	          // trump.jpg, putin.png
	          String imageFileName = person.getImageFileName();
	          System.out.println("File Name: "+ imageFileName);
	        
	          // image/jpg
	          // image/png
	          String contentType = this.getServletContext().getMimeType(imageFileName);
	          System.out.println("Content Type: "+ contentType);
	        
	          response.setHeader("Content-Type", contentType);
	        
	          response.setHeader("Content-Length", String.valueOf(person.getImageData().length));
	        
	          response.setHeader("Content-Disposition", "inline; filename=\"" + person.getImageFileName() + "\"");
	 
	          // Write image data to Response.
	          response.getOutputStream().write(person.getImageData());
	 
	      } catch (Exception e) {
	          throw new ServletException(e);
	      }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	}

}
